
import React from 'react';
import styled from 'styled-components';
import { typesData } from './typesData';

const TypeBox = styled.div<{ bgColor: string }>`
  background-color: ${({ bgColor }) => bgColor};
  color: white;
  padding: 20px;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-family: Arial, sans-serif;
  font-weight: bold;
  margin: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  position: relative;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover .hover-card {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
  }
`;

const TypeTitle = styled.div`
  font-size: 18px;
  margin-bottom: 10px;
`;

const FunctionPairing = styled.div`
  font-size: 14px;
  margin-bottom: 5px;
`;

const HoverCard = styled.div`
  position: absolute;
  bottom: 100%;
  left: 50%;
  transform: translateX(-50%) translateY(10px);
  background-color: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 10px;
  border-radius: 8px;
  opacity: 0;
  visibility: hidden;
  transition: all 0.3s ease;
  white-space: nowrap;
  text-align: center;
`;

interface TypeProps {
  type: string;
  functions: string[];
  mode: string;
  bgColor: string;
  bronze: string;
  silver: string;
  gold: string;
}

const Type: React.FC<TypeProps> = ({ type, functions, mode, bgColor, bronze, silver, gold }) => {
  return (
    <TypeBox bgColor={bgColor}>
      <TypeTitle>{type}</TypeTitle>
      {functions.map((func, index) => (
        <FunctionPairing key={index}>{func}</FunctionPairing>
      ))}
      <HoverCard className="hover-card">
        <div><span style={{ color: '#cd7f32' }}>Bronze:</span> {bronze}</div>
        <div><span style={{ color: '#c0c0c0' }}>Silver:</span> {silver}</div>
        <div><span style={{ color: '#ffd700' }}>Gold:</span> {gold}</div>
      </HoverCard>
    </TypeBox>
  );
};

const MatrixContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  padding: 20px;
  background-color: white;
  border-radius: 10px;
`;

const Matrix: React.FC = () => {
  return (
    <MatrixContainer>
      {typesData.map((typeData) => (
        <Type
          key={typeData.type}
          type={typeData.type}
          functions={typeData.functions}
          mode={typeData.mode}
          bgColor={typeData.bgColor}
          bronze={typeData.bronze}
          silver={typeData.silver}
          gold={typeData.gold}
        />
      ))}
    </MatrixContainer>
  );
};

export default Matrix;
